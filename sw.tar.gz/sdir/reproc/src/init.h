#pragma once

int init(void);

void deinit(void);
